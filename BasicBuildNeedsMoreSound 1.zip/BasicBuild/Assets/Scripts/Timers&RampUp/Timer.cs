using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class Timer : MonoBehaviour
{
    
     // set the countdown time in seconds
    public TextMeshProUGUI countdownText;
    public static bool timerPause;
    bool pause;
    // Start is called before the first frame update
    void Start()
    {
        timerPause = false;
    }

    // Update is called once per frame
    void Update()
    {


        if (timerPause == true)
        {
           GameManager.timeLeft = 1;
        }
        else
        {
            GameManager.timeLeft -= Time.deltaTime; // reduce the time left by the time passed since the last frame
        }
         
        countdownText.text = "Time Left: " + Mathf.Round(GameManager.timeLeft).ToString(); // update the UI text object with the time left rounded to the nearest whole number

        if (GameManager.timeLeft <= 0) 
        {
            GameManager.loseDumby = true;   
            timerPause = true;
        }
    }
}
