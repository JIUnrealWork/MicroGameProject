using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;
using UnityEngine.UI;

public class RampUpScript : MonoBehaviour
{
    public static float minusTime = 0.3f;

    public GameObject textObject;

    private TMP_Text enabledText;
    
    // Start is called before the first frame update
    void Start()
    {
        enabledText = textObject.GetComponent<TMP_Text>();
        if(GameManager.timeLeft >= 0.6)
        {
            
            StartCoroutine(ExecuteAfterTime(2));
            
            IEnumerator ExecuteAfterTime(float time)
            {

             //GameManager.timeLeft -= minusTime;
             
             yield return new WaitForSeconds(2.0f);
             Debug.Log(" the minus timer transition thing is working correctly");
             textObject.SetActive(true);
             

             yield return new WaitForSeconds(2.0f);   
             SceneManager.LoadScene("SampleScene");
             


            }
        }
        else
        {
            StartCoroutine(ExecuteAfterTime(2));

            IEnumerator ExecuteAfterTime(float time)
            {
               // Debug.Log("Do Nothing");
                
                yield return new WaitForSeconds(2.0f);

                // Code to execute after the delay
                
                SceneManager.LoadScene("SampleScene");
            }
        }

    }
   

    // Update is called once per frame
    void Update()
    {
        
    }
}
