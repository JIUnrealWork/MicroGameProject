using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class GameManager : MonoBehaviour
{
    TextMeshProUGUI fasterText;
    public GameObject ArrowThing;
    [SerializeField] public static bool winDumby;
    [SerializeField] public static bool loseDumby;
    [SerializeField] public static float timeLeft;
    [SerializeField] public static float baseSpeed = 7.0f;
    static public int countUpScore =1;
    [SerializeField] public static float currentScore;
    bool  win;
    bool lose;
    // Start is called before the first frame update
    void Start()
    {        
        winDumby = false;
        loseDumby = false;
        /* speed = speed -- rampup? need to look into this later, could use a seperate variable that adds to itself on start.
         Also need to find a different way to stop the arrow without messing with the speed temporarily 
         as right now the game sort of breaks as the arrow stays still after pressing space for the first time
         
         Also need to fix timer as it keeps the time from previose starts which is kind of anoying 
         as i dont know another way to keep the time value where it is while also subtracting it 
         with an increasing value without the base time being forever whittled down by it just counting down ingame
         PRIORITISE THIS    PRIORITISE THIS     PRIORITISE THIS     PRIORITISE THIS
         */
        timeLeft = 5.0f ;
        

    }


     public void WinGame()
     {
        SceneManager.LoadScene("WinScene");
        baseSpeed = 7;
        baseSpeed += countUpScore;
     }

    public void LoseGame()
    {
        SceneManager.LoadScene("LoseScene");
        countUpScore = 0;
        currentScore = 0;
        baseSpeed = 7.0f;
    }

    /*
    if(!win)
    {
    win = true;
    Invoke("WinGame", 3f);
    }


    */

    // Update is called once per frame
    void Update()
    {
        

        if(winDumby && !win) //this is only done once as the win bool prevents the update method from constantly calling the win function.
        {
            win = true;
            // AutoMovement.incrementSpeed ++ baseSpeed;
            baseSpeed = 0;
            Invoke("WinGame", 3f);
            countUpScore++;

        }

        if(loseDumby &&!lose)
        {
            lose = true;
            baseSpeed = 0;
            Invoke("LoseGame", 1.5f);
        }
    }
}
