using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;


public class Score : MonoBehaviour
{
    private int scoreAddNumber;

    public static int highScore;
    // Start is called before the first frame update
    void Start()
    {
        scoreAddNumber = 1;
        

        if (GameManager.winDumby == true)
        {
          
            GameManager.currentScore += scoreAddNumber ; 
            Debug.Log("score :" + GameManager.currentScore.ToString());

        }
        
        
        if (GameManager.currentScore > highScore)
        {
            highScore = (int)GameManager.currentScore;
            Debug.Log("HighScore :" + highScore.ToString());
        }


    }

    // Update is called once per frame
    void Update()
    {
       
    }
}
