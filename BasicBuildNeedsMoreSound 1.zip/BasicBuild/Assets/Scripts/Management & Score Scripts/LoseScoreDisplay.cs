using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class LoseScoreDisplay : MonoBehaviour
{
    public TMP_Text finalScoreDisplay;

    // Start is called before the first frame update
    void Start()
    {
        finalScoreDisplay.SetText("Here's your final score: " + GameManager.currentScore);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
