using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Animations : MonoBehaviour
{
    // Start is called before the first frame update
    

    private Animator animateBow;

    private Animator boomAnimation;
    
    //public static float incrementSpeed;

    void Start()
    {
        animateBow = gameObject.GetComponent<Animator>();
        boomAnimation = gameObject.GetComponent<Animator>();
    }


    public void BowAnimation()
    {
        
        
     animateBow.SetTrigger("bowShoot");
            
        
        
        
    }

    public void CastleCrush()
    {
        boomAnimation.SetTrigger("boomAnimated");
    }

    // Update is called once per frame
    void Update()
    {
        //animateBow.Play("bowAnimation");
    }
}
    