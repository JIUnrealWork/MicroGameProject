using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class ArrowMovement : MonoBehaviour
{
    bool space;

    public Animations other;


    public AudioSource audioSource1;
    public AudioSource audioSource2;

    public float targetYPosition = 5.0f;  // The target x position the object should move towards
    public float moveSpeed = 5.0f;        // The speed of the movement

    private Vector2 targetPosition;       // The target position the object should move towards
    private bool isMoving = false;        // Flag to check if the object is currently moving

    void Start()
    {
        targetPosition = new Vector2(transform.position.x, targetYPosition); // this gets the position of where i want to move too, so X and Z are zero but Y is changed
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space) && !isMoving) // so if the spacebar is pressed  and the bool isMoving is false then it will set isMoving to true
        {
            isMoving = true;
        }
    }

    void FixedUpdate()
    {
        if (isMoving) // this detects if isMoving is true, and if it is it will trigger the custom event, MoveObject
        {
            MoveObject();
        }
    }

    void MoveObject() // this custom event is what moves the object
    {
        Vector2 currentPosition = new Vector2(transform.position.x, transform.position.y); //this part gets the location of the object
        Vector2 newPosition = Vector2.MoveTowards(currentPosition, targetPosition, moveSpeed * Time.deltaTime); //this part of the script makes calculates the new position using the Vector2 move towards method, which takes the current position, target position and a maximum distance to move.
                //and then it is applied to the objects rigidbody making it move to that position. it then finally checks if the target position is equal to the new position, and if true it stops moving by setting the isMoving bool to false
        GetComponent<Rigidbody2D>().MovePosition(newPosition); 

        if (newPosition == targetPosition)
        {
            isMoving = false;
        }
    }


/*private void Update()
{
    if (Input.GetKeyDown(KeyCode.Space))
    {
        transform.position += new Vector3(0, 3*Time.deltaTime, 0);
    }

    /*
    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.Space))
        {
            MoveBlock();

        }



    }
    void MoveBlock()
    {
        transform.position = new Vector2(transform.position.x, 3) * Time.deltaTime * 2;

    }
    /
}*/
    void OnCollisionEnter2D(Collision2D collision)
    {


        if (collision.gameObject.CompareTag("Target"))
        {
            audioSource1.Play();
            
            other.CastleCrush();

        }
    }


    
}