using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BowShoot : MonoBehaviour
{

    public Animations other;


    [SerializeField]
    private AudioClip bowShootSFX;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {


        if (Input.GetKeyDown(KeyCode.Space))
        {
            //Debug.Log("this works");
            AudioSource.PlayClipAtPoint(bowShootSFX, transform.position);
            other.BowAnimation();

            RaycastHit2D hit = Physics2D.Raycast(transform.position, transform.TransformDirection(Vector2.up), 2f);
            if (hit)
            {

                Debug.Log("Hit Something : " + hit.collider.name);


                //incrementSpeed++;
                GameManager.winDumby = true;
                Timer.timerPause = true;

            }
            else
            {

                Debug.Log("you missed");
                GameManager.loseDumby = true;
                GameManager.baseSpeed = 7.0f;
                Timer.timerPause = true;

            }

        }

    }
}
